// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_AIR_APOLLO_Ax.h"

void CAG_AIR_APOLLO_Ax::checkDebug()
{
	APIFlavor=AIRAx_API;	
}

CAG_AIR_APOLLO_Ax::CAG_AIR_APOLLO_Ax()
{
	
}

CAG_AIR_APOLLO_Ax::~CAG_AIR_APOLLO_Ax()
{
	
}

void CAG_AIR_APOLLO_Ax::generateHeader(CStringArray* pcsaHeader,
									   CStringArray* pcsaBody)
{
	
}

void CAG_AIR_APOLLO_Ax::appendBody(int nFunctionNum,
								   bool bPromptForValues,
								   CStringArray* pcsaArguments,
								   CStringArray* pcsaHeader,
								   CStringArray* pcsaBody)
{
	
}

void CAG_AIR_APOLLO_Ax::finalize(CStringArray* pcsaBody)
{
	
}

void CAG_AIR_APOLLO_Ax::declareVariable(AG_VARIABLE agVariable,
										CStringArray* pcsaHeader,
										bool* bValue)
{
	
}
