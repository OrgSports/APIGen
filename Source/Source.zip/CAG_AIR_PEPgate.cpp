// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_AIR_PEPgate.h"

void CAG_AIR_PEPgate::loadFunctionList(CListBox* listTranslateFunction)
{
	
}

void CAG_AIR_PEPgate::loadLanguageList(CListBox* listTranslateLanguage)
{
	
}

CAG_AIR_PEPgate::CAG_AIR_PEPgate()
{
	
}

CAG_AIR_PEPgate::~CAG_AIR_PEPgate()
{
	
}

void CAG_AIR_PEPgate::generateHeader(CStringArray* pcsaHeader,
									 CStringArray* pcsaBody)
{
	
}

void CAG_AIR_PEPgate::appendBody(int nFunctionNum,
								 bool bPromptForValues,
								 CStringArray* pcsaArguments,
								 CStringArray* pcsaHeader,
								 CStringArray* pcsaBody)
{
	
}

void CAG_AIR_PEPgate::finalize(CStringArray* pcsaBody)
{
	
}

void CAG_AIR_PEPgate::declareVariable(AG_VARIABLE agVariable,
									  CStringArray* pcsaHeader,
									  bool* bValue)
{
	
}
