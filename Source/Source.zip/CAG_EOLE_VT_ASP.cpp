// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_EOLE_VT_ASP.h"

CAG_EOLE_VT_ASP::CAG_EOLE_VT_ASP()
{
	resetVariableFlags();
}

CAG_EOLE_VT_ASP::~CAG_EOLE_VT_ASP()
{
	
}

void CAG_EOLE_VT_ASP::declareVariable(AG_VARIABLE agVariable,
									  CStringArray* pcsaHeader,
									  bool* bValue)
{
	
}

void CAG_EOLE_VT_ASP::checkDebug(bool b_Debug,
									   CString csFunctionName,
									   CStringArray* pcsaBody)
{
	
}

void CAG_EOLE_VT_ASP::resetVariableFlags()
{

}

void CAG_EOLE_VT_ASP::generateHeader(CStringArray* csaHeader,
									 CStringArray* csaBody)
{
	
}

void CAG_EOLE_VT_ASP::appendBody(int nFunctionNum,
								 bool bPromptForValues,
								 CStringArray* csaArguments,
								 CStringArray* csaHeader,
								 CStringArray* csaBody)
{
	
}

void CAG_EOLE_VT_ASP::finalize(CStringArray* pcsaBody)
{
	
}
