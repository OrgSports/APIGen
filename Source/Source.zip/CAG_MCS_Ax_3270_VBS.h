// Static Model


#ifndef __CAG_MCS_AX_3270_VBS__
#define __CAG_MCS_AX_3270_VBS__


// Include files
#include "CAG_MCS_Ax_3270.h"
class CAG_MCS_Ax_3270_VBS : public CAG_MCS_Ax_3270
{

public:

	~CAG_MCS_Ax_3270_VBS();

protected:

	CAG_MCS_Ax_3270_VBS();

};// END CLASS DEFINITION CAG_MCS_Ax_3270_VBS

#endif // __CAG_MCS_AX_3270_VBS__
