// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_EOLE_VT_CS.h"

CAG_EOLE_VT_CS::CAG_EOLE_VT_CS()
{
	resetVariableFlags();	
}

CAG_EOLE_VT_CS::~CAG_EOLE_VT_CS()
{
	
}

void CAG_EOLE_VT_CS::declareVariable(AG_VARIABLE agVariable,
									 CStringArray* pcsaHeader,
									 bool* bValue)
{
	
}


void CAG_EOLE_VT_CS::generateHeader(CStringArray* csaHeader,
									CStringArray* csaBody)
{
	
}

void CAG_EOLE_VT_CS::appendBody(int nFunctionNum,
								bool bPromptForValues,
								CStringArray* csaArguments,
								CStringArray* csaHeader,
								CStringArray* csaBody)
{
	
}

void CAG_EOLE_VT_CS::finalize(CStringArray* pcsaBody)
{
	
}


void CAG_EOLE_VT_CS::checkDebug(bool b_Debug,
									   CString csFunctionName,
									   CStringArray* pcsaBody)
{
	
}

void CAG_EOLE_VT_CS::resetVariableFlags()
{

}
