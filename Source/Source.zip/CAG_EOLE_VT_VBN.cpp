// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_EOLE_VT_VBN.h"

CAG_EOLE_VT_VBN::CAG_EOLE_VT_VBN()
{
	resetVariableFlags();	
}

CAG_EOLE_VT_VBN::~CAG_EOLE_VT_VBN()
{
	
}

void CAG_EOLE_VT_VBN::declareVariable(AG_VARIABLE agVariable,
									  CStringArray* pcsaHeader,
									  bool* bValue)
{
	
}

void CAG_EOLE_VT_VBN::checkDebug(bool b_Debug,
									   CString csFunctionName,
									   CStringArray* pcsaBody)
{
	
}

void CAG_EOLE_VT_VBN::resetVariableFlags()
{

}

void CAG_EOLE_VT_VBN::generateHeader(CStringArray* csaHeader,
									 CStringArray* csaBody)
{
	
}

void CAG_EOLE_VT_VBN::appendBody(int nFunctionNum,
								 bool bPromptForValues,
								 CStringArray* csaArguments,
								 CStringArray* csaHeader,
								 CStringArray* csaBody)
{
	
}

void CAG_EOLE_VT_VBN::finalize(CStringArray* pcsaBody)
{
	
}
