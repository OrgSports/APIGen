// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_AIR_MCS.h"

void CAG_AIR_MCS::loadFunctionList(CListBox* listTranslateFunction)
{
	
}

void CAG_AIR_MCS::loadLanguageList(CListBox* listTranslateLanguage)
{
	
}

CAG_AIR_MCS::CAG_AIR_MCS()
{
	
}

CAG_AIR_MCS::~CAG_AIR_MCS()
{
	
}

void CAG_AIR_MCS::generateHeader(CStringArray* pcsaHeader,
								 CStringArray* pcsaBody)
{
	
}

void CAG_AIR_MCS::appendBody(int nFunctionNum,
							 bool bPromptForValues,
							 CStringArray* pcsaArguments,
							 CStringArray* pcsaHeader,
							 CStringArray* pcsaBody)
{
	
}

void CAG_AIR_MCS::finalize(CStringArray* pcsaBody)
{
	
}

void CAG_AIR_MCS::declareVariable(AG_VARIABLE agVariable,
								  CStringArray* pcsaHeader,
								  bool* bValue)
{
	
}
