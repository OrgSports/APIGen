// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_AIR_EDS.h"

void CAG_AIR_EDS::loadFunctionList(CListBox* listTranslateFunction)
{
	
}

void CAG_AIR_EDS::loadLanguageList(CListBox* listTranslateLanguage)
{
	
}

CAG_AIR_EDS::CAG_AIR_EDS()
{
	
}

CAG_AIR_EDS::~CAG_AIR_EDS()
{
	
}

void CAG_AIR_EDS::generateHeader(CStringArray* pcsaHeader,
								 CStringArray* pcsaBody)
{
	
}

void CAG_AIR_EDS::appendBody(int nFunctionNum,
							 bool bPromptForValues,
							 CStringArray* pcsaArguments,
							 CStringArray* pcsaHeader,
							 CStringArray* pcsaBody)
{
	
}

void CAG_AIR_EDS::finalize(CStringArray* pcsaBody)
{
	
}

void CAG_AIR_EDS::declareVariable(AG_VARIABLE agVariable,
								  CStringArray* pcsaHeader,
								  bool* bValue)
{
	
}
