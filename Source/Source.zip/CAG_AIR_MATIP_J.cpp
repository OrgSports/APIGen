// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_AIR_MATIP_J.h"

void CAG_AIR_MATIP_J::checkDebug()
{

}

CAG_AIR_MATIP_J::CAG_AIR_MATIP_J()
{
	APIFlavor = AIRJ_API;	
}

CAG_AIR_MATIP_J::~CAG_AIR_MATIP_J()
{
	
}

void CAG_AIR_MATIP_J::generateHeader(CStringArray* pcsaHeader,
									 CStringArray* pcsaBody)
{
	
}

void CAG_AIR_MATIP_J::appendBody(int nFunctionNum,
								 bool bPromptForValues,
								 CStringArray* pcsaArguments,
								 CStringArray* pcsaHeader,
								 CStringArray* pcsaBody)
{
	
}

void CAG_AIR_MATIP_J::finalize(CStringArray* pcsaBody)
{
	
}

void CAG_AIR_MATIP_J::declareVariable(AG_VARIABLE agVariable,
									  CStringArray* pcsaHeader,
									  bool* bValue)
{
	
}
