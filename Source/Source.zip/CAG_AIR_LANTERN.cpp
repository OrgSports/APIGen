// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_AIR_LANTERN.h"

void CAG_AIR_LANTERN::loadFunctionList(CListBox* listTranslateFunction)
{
	
}

void CAG_AIR_LANTERN::loadLanguageList(CListBox* listTranslateLanguage)
{
	
}

CAG_AIR_LANTERN::CAG_AIR_LANTERN()
{
	
}

CAG_AIR_LANTERN::~CAG_AIR_LANTERN()
{
	
}

void CAG_AIR_LANTERN::generateHeader(CStringArray* pcsaHeader,
									 CStringArray* pcsaBody)
{
	
}

void CAG_AIR_LANTERN::appendBody(int nFunctionNum,
								 bool bPromptForValues,
								 CStringArray* pcsaArguments,
								 CStringArray* pcsaHeader,
								 CStringArray* pcsaBody)
{
	
}

void CAG_AIR_LANTERN::finalize(CStringArray* pcsaBody)
{
	
}

void CAG_AIR_LANTERN::declareVariable(AG_VARIABLE agVariable,
									  CStringArray* pcsaHeader,
									  bool* bValue)
{
	
}
