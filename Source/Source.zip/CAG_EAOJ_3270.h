// Static Model


#ifndef __CAG_EAOJ_3270__
#define __CAG_EAOJ_3270__


// Include files
#include "CAG_EAOJ.h"
class CAG_EAOJ_3270 : public CAG_EAOJ
{

public:

	~CAG_EAOJ_3270();

	void loadFunctionList(CListBox* listTranslateFunction);

protected:

	CAG_EAOJ_3270();

};// END CLASS DEFINITION CAG_EAOJ_3270

#endif // __CAG_EAOJ_3270__
