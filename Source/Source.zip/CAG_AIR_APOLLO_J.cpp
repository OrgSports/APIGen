// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_AIR_APOLLO_J.h"

void CAG_AIR_APOLLO_J::checkDebug()
{

}

CAG_AIR_APOLLO_J::CAG_AIR_APOLLO_J()
{
	APIFlavor = AIRJ_API;			
}

CAG_AIR_APOLLO_J::~CAG_AIR_APOLLO_J()
{
	
}

void CAG_AIR_APOLLO_J::generateHeader(CStringArray* pcsaHeader,
									  CStringArray* pcsaBody)
{
	
}

void CAG_AIR_APOLLO_J::appendBody(int nFunctionNum,
								  bool bPromptForValues,
								  CStringArray* pcsaArguments,
								  CStringArray* pcsaHeader,
								  CStringArray* pcsaBody)
{
	
}

void CAG_AIR_APOLLO_J::finalize(CStringArray* pcsaBody)
{
	
}

void CAG_AIR_APOLLO_J::declareVariable(AG_VARIABLE agVariable,
									   CStringArray* pcsaHeader,
									   bool* bValue)
{
	
}
