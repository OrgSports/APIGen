// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_AIR_SABRE.h"

void CAG_AIR_SABRE::loadFunctionList(CListBox* listTranslateFunction)
{
	
}

void CAG_AIR_SABRE::loadLanguageList(CListBox* listTranslateLanguage)
{
	
}

CAG_AIR_SABRE::CAG_AIR_SABRE()
{
	
}

CAG_AIR_SABRE::~CAG_AIR_SABRE()
{
	
}

void CAG_AIR_SABRE::generateHeader(CStringArray* pcsaHeader,
								   CStringArray* pcsaBody)
{
	
}

void CAG_AIR_SABRE::appendBody(int nFunctionNum,
							   bool bPromptForValues,
							   CStringArray* pcsaArguments,
							   CStringArray* pcsaHeader,
							   CStringArray* pcsaBody)
{
	
}

void CAG_AIR_SABRE::finalize(CStringArray* pcsaBody)
{}

void CAG_AIR_SABRE::declareVariable(AG_VARIABLE agVariable,
									CStringArray* pcsaHeader,
									bool* bValue)
{
	
}
