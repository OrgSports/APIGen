// Static Model


#ifndef __CAG_EAOAX_3270__
#define __CAG_EAOAX_3270__


// Include files
#include "CAG_EAOAx.h"
class CAG_EAOAx_3270 : public CAG_EAOAx
{

public:

	~CAG_EAOAx_3270();

	void loadFunctionList(CListBox* listTranslateFunction);

protected:

	CAG_EAOAx_3270();

};// END CLASS DEFINITION CAG_EAOAx_3270

#endif // __CAG_EAOAX_3270__
