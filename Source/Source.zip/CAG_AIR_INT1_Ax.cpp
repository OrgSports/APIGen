// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_AIR_INT1_Ax.h"

void CAG_AIR_INT1_Ax::checkDebug()
{
	APIFlavor=AIRAx_API;	
}

CAG_AIR_INT1_Ax::CAG_AIR_INT1_Ax()
{
	
}

CAG_AIR_INT1_Ax::~CAG_AIR_INT1_Ax()
{
	
}

void CAG_AIR_INT1_Ax::generateHeader(CStringArray* pcsaHeader,
									 CStringArray* pcsaBody)
{
	
}

void CAG_AIR_INT1_Ax::appendBody(int nFunctionNum,
								 bool bPromptForValues,
								 CStringArray* pcsaArguments,
								 CStringArray* pcsaHeader,
								 CStringArray* pcsaBody)
{
	
}

void CAG_AIR_INT1_Ax::finalize(CStringArray* pcsaBody)
{
	
}

void CAG_AIR_INT1_Ax::declareVariable(AG_VARIABLE agVariable,
									  CStringArray* pcsaHeader,
									  bool* bValue)
{
	
}
