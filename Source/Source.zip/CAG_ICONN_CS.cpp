// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_ICONN_CS.h"

CAG_ICONN_CS::CAG_ICONN_CS()
{
	
}

CAG_ICONN_CS::~CAG_ICONN_CS()
{
	
}

void CAG_ICONN_CS::declareVariable(AG_VARIABLE agVariable,
										CStringArray* pcsaHeader,
										bool* bValue)
{
	
}

void CAG_ICONN_CS::checkDebug(bool b_Debug,
								   CString csFunctionName,
								   CStringArray* pcsaBody)
{
	
}

void CAG_ICONN_CS::generateHeader(CStringArray* csaHeader,
									   CStringArray* csaBody)
{
	
}

void CAG_ICONN_CS::appendBody(int nFunctionNum,
								   bool bPromptForValues,
								   CStringArray* csaArguments,
								   CStringArray* csaHeader,
								   CStringArray* csaBody)
{
	
}

void CAG_ICONN_CS::finalize(CStringArray* pcsaBody)
{
	
}
