// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_EOLE_5250_XLS.h"

CAG_EOLE_5250_XLS::CAG_EOLE_5250_XLS()
{
	resetVariableFlags();	
}

CAG_EOLE_5250_XLS::~CAG_EOLE_5250_XLS()
{
	
}

void CAG_EOLE_5250_XLS::declareVariable(AG_VARIABLE agVariable,
										CStringArray* pcsaHeader,
										bool* bValue)
{
	
}

void CAG_EOLE_5250_XLS::checkDebug(bool b_Debug,
									   CString csFunctionName,
									   CStringArray* pcsaBody)
{
	
}

void CAG_EOLE_5250_XLS::resetVariableFlags()
{

}

void CAG_EOLE_5250_XLS::generateHeader(CStringArray* csaHeader,
									   CStringArray* csaBody)
{
	
}

void CAG_EOLE_5250_XLS::appendBody(int nFunctionNum,
								   bool bPromptForValues,
								   CStringArray* csaArguments,
								   CStringArray* csaHeader,
								   CStringArray* csaBody)
{
	
}

void CAG_EOLE_5250_XLS::finalize(CStringArray* pcsaBody)
{
	
}
