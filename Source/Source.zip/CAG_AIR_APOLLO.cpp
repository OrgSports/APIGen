// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_AIR_APOLLO.h"

void CAG_AIR_APOLLO::loadFunctionList(CListBox* listTranslateFunction)
{
	
}

void CAG_AIR_APOLLO::loadLanguageList(CListBox* listTranslateLanguage)
{
	
}

CAG_AIR_APOLLO::CAG_AIR_APOLLO()
{
	
}

CAG_AIR_APOLLO::~CAG_AIR_APOLLO()
{
	
}

void CAG_AIR_APOLLO::generateHeader(CStringArray* pcsaHeader,
									CStringArray* pcsaBody)
{
	
}

void CAG_AIR_APOLLO::appendBody(int nFunctionNum,
								bool bPromptForValues,
								CStringArray* pcsaArguments,
								CStringArray* pcsaHeader,
								CStringArray* pcsaBody)
{
	
}

void CAG_AIR_APOLLO::finalize(CStringArray* pcsaBody)
{
	
}

void CAG_AIR_APOLLO::declareVariable(AG_VARIABLE agVariable,
									 CStringArray* pcsaHeader,
									 bool* bValue)
{
	
}
