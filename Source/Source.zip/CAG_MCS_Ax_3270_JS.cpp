// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_MCS_Ax_3270_JS.h"

CAG_MCS_Ax_3270_JS::~CAG_MCS_Ax_3270_JS()
{
	
}

CAG_MCS_Ax_3270_JS::CAG_MCS_Ax_3270_JS()
{
	
}
