// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_AIR_T27_Ax.h"

CAG_AIR_T27_Ax::~CAG_AIR_T27_Ax()
{

}

CAG_AIR_T27_Ax::CAG_AIR_T27_Ax()
{
	APIFlavor=AIRAx_API;	
}

void CAG_AIR_T27_Ax::generateHeader(CStringArray* pcsaHeader,
									CStringArray* pcsaBody)
{
	
}

void CAG_AIR_T27_Ax::appendBody(int nFunctionNum,
								bool bPromptForValues,
								CStringArray* pcsaArguments,
								CStringArray* pcsaHeader,
								CStringArray* pcsaBody)
{
	
}

void CAG_AIR_T27_Ax::finalize(CStringArray* pcsaBody)
{
	
}

void CAG_AIR_T27_Ax::declareVariable(AG_VARIABLE agVariable,
									 CStringArray* pcsaHeader,
									 bool* bValue)
{
	
}

void CAG_AIR_T27_Ax::checkDebug()
{
	
}
