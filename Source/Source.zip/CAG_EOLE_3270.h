// Static Model


#ifndef __CAG_EOLE_3270__
#define __CAG_EOLE_3270__


// Include files
#include "CAG_EOLE.h"
class CAG_EOLE_3270 : public CAG_EOLE
{

public:

	~CAG_EOLE_3270();

	void loadFunctionList(CListBox* listTranslateFunction);

protected:

	CAG_EOLE_3270();


};// END CLASS DEFINITION CAG_EOLE_3270

#endif // __CAG_EOLE_3270__
