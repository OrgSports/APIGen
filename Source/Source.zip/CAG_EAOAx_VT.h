// Static Model


#ifndef __CAG_EAOAX_VT__
#define __CAG_EAOAX_VT__


// Include files
#include "CAG_EAOAx.h"
class CAG_EAOAx_VT : public CAG_EAOAx
{

public:

	~CAG_EAOAx_VT();

	void loadFunctionList(CListBox* listTranslateFunction);

protected:

	CAG_EAOAx_VT();

};// END CLASS DEFINITION CAG_EAOAx_VT

#endif // __CAG_EAOAX_VT__
