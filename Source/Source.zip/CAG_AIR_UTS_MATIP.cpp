// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_AIR_UTS_MATIP.h"

void CAG_AIR_UTS_MATIP::loadFunctionList(CListBox* listTranslateFunction)
{
	
}

void CAG_AIR_UTS_MATIP::loadLanguageList(CListBox* listTranslateLanguage)
{
	
}

CAG_AIR_UTS_MATIP::CAG_AIR_UTS_MATIP()
{
	
}

CAG_AIR_UTS_MATIP::~CAG_AIR_UTS_MATIP()
{
	
}

void CAG_AIR_UTS_MATIP::generateHeader(CStringArray* pcsaHeader,
									   CStringArray* pcsaBody)
{
	
}

void CAG_AIR_UTS_MATIP::appendBody(int nFunctionNum,
								   bool bPromptForValues,
								   CStringArray* pcsaArguments,
								   CStringArray* pcsaHeader,
								   CStringArray* pcsaBody)
{
	
}

void CAG_AIR_UTS_MATIP::finalize(CStringArray* pcsaBody)
{
	
}

void CAG_AIR_UTS_MATIP::declareVariable(AG_VARIABLE agVariable,
										CStringArray* pcsaHeader,
										bool* bValue)
{
	
}
