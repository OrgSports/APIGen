// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_AIR_T27_J.h"

void CAG_AIR_T27_J::checkDebug()
{
	
}

CAG_AIR_T27_J::CAG_AIR_T27_J()
{
	APIFlavor = AIRJ_API;	
}

CAG_AIR_T27_J::~CAG_AIR_T27_J()
{
	
}

void CAG_AIR_T27_J::generateHeader(CStringArray* pcsaHeader,
								   CStringArray* pcsaBody)
{
	
}

void CAG_AIR_T27_J::appendBody(int nFunctionNum,
							   bool bPromptForValues,
							   CStringArray* pcsaArguments,
							   CStringArray* pcsaHeader,
							   CStringArray* pcsaBody)
{
	
}

void CAG_AIR_T27_J::finalize(CStringArray* pcsaBody)
{
	
}

void CAG_AIR_T27_J::declareVariable(AG_VARIABLE agVariable,
									CStringArray* pcsaHeader,
									bool* bValue)
{
	
}
