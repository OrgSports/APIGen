// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_AIR_INT1.h"

void CAG_AIR_INT1::loadFunctionList(CListBox* listTranslateFunction)
{
	
}

void CAG_AIR_INT1::loadLanguageList(CListBox* listTranslateLanguage)
{
	
}

CAG_AIR_INT1::CAG_AIR_INT1()
{
	
}

CAG_AIR_INT1::~CAG_AIR_INT1()
{
	
}

void CAG_AIR_INT1::generateHeader(CStringArray* pcsaHeader,
								  CStringArray* pcsaBody)
{
	
}

void CAG_AIR_INT1::appendBody(int nFunctionNum,
							  bool bPromptForValues,
							  CStringArray* pcsaArguments,
							  CStringArray* pcsaHeader,
							  CStringArray* pcsaBody)
{
	
}

void CAG_AIR_INT1::finalize(CStringArray* pcsaBody)
{
	
}

void CAG_AIR_INT1::declareVariable(AG_VARIABLE agVariable,
								   CStringArray* pcsaHeader,
								   bool* bValue)
{
	
}
