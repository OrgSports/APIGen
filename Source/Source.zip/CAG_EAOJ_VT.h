// Static Model


#ifndef __CAG_EAOJ_VT__
#define __CAG_EAOJ_VT__


// Include files
#include "CAG_EAOJ.h"
class CAG_EAOJ_VT : public CAG_EAOJ
{

public:

	~CAG_EAOJ_VT();

	void loadFunctionList(CListBox* listTranslateFunction);

protected:

	CAG_EAOJ_VT();

};// END CLASS DEFINITION CAG_EAOJ_VT

#endif // __CAG_EAOJ_VT__
