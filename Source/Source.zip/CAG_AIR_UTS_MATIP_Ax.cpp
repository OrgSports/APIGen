// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_AIR_UTS_MATIP_Ax.h"

void CAG_AIR_UTS_MATIP_Ax::checkDebug()
{
	
}

CAG_AIR_UTS_MATIP_Ax::CAG_AIR_UTS_MATIP_Ax()
{
	APIFlavor=AIRAx_API;	
}

CAG_AIR_UTS_MATIP_Ax::~CAG_AIR_UTS_MATIP_Ax()
{
	
}

void CAG_AIR_UTS_MATIP_Ax::generateHeader(CStringArray* pcsaHeader,
										  CStringArray* pcsaBody)
{
	
}

void CAG_AIR_UTS_MATIP_Ax::appendBody(int nFunctionNum,
									  bool bPromptForValues,
									  CStringArray* pcsaArguments,
									  CStringArray* pcsaHeader,
									  CStringArray* pcsaBody)
{
	
}

void CAG_AIR_UTS_MATIP_Ax::finalize(CStringArray* pcsaBody)
{
	
}

void CAG_AIR_UTS_MATIP_Ax::declareVariable(AG_VARIABLE agVariable,
										   CStringArray* pcsaHeader,
										   bool* bValue)
{
	
}
