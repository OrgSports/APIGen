// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_AIR_PEPgate_Ax_CS.h"

CAG_AIR_PEPgate_Ax_CS::CAG_AIR_PEPgate_Ax_CS()
{
	resetVariableFlags();	
}

CAG_AIR_PEPgate_Ax_CS::~CAG_AIR_PEPgate_Ax_CS()
{
	
}

void CAG_AIR_PEPgate_Ax_CS::checkDebug(bool b_Debug,
									   CString csFunctionName,
									   CStringArray* pcsaBody)
{
	
}

void CAG_AIR_PEPgate_Ax_CS::generateHeader(CStringArray* pcsaHeader,
										   CStringArray* pcsaBody)
{
	
}

void CAG_AIR_PEPgate_Ax_CS::appendBody(int nFunctionNum,
									   bool bPromptForValues,
									   CStringArray* pcsaArguments,
									   CStringArray* pcsaHeader,
									   CStringArray* pcsaBody)
{
	
}

void CAG_AIR_PEPgate_Ax_CS::finalize(CStringArray* pcsaBody)
{
	
}

void CAG_AIR_PEPgate_Ax_CS::declareVariable(AG_VARIABLE agVariable,
											CStringArray* pcsaHeader,
											bool* bValue)
{
	
}

void CAG_AIR_PEPgate_Ax_CS::resetVariableFlags()
{
}