// Static Model


#ifndef __CAG_EAOJ_5250__
#define __CAG_EAOJ_5250__


// Include files
#include "CAG_EAOJ.h"
class CAG_EAOJ_5250 : public CAG_EAOJ
{

public:

	~CAG_EAOJ_5250();

	void loadFunctionList(CListBox* listTranslateFunction);

protected:

	CAG_EAOJ_5250();

};// END CLASS DEFINITION CAG_EAOJ_5250

#endif // __CAG_EAOJ_5250__
