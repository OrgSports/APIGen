// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_AIR_LANTERN_Ax.h"

void CAG_AIR_LANTERN_Ax::checkDebug()
{
	
}

CAG_AIR_LANTERN_Ax::CAG_AIR_LANTERN_Ax()
{
	APIFlavor=AIRAx_API;	
}

CAG_AIR_LANTERN_Ax::~CAG_AIR_LANTERN_Ax()
{
	
}

void CAG_AIR_LANTERN_Ax::generateHeader(CStringArray* pcsaHeader,
										CStringArray* pcsaBody)
{
	
}

void CAG_AIR_LANTERN_Ax::appendBody(int nFunctionNum,
									bool bPromptForValues,
									CStringArray* pcsaArguments,
									CStringArray* pcsaHeader,
									CStringArray* pcsaBody)
{
	
}

void CAG_AIR_LANTERN_Ax::finalize(CStringArray* pcsaBody)
{
	
}

void CAG_AIR_LANTERN_Ax::declareVariable(AG_VARIABLE agVariable,
										 CStringArray* pcsaHeader,
										 bool* bValue)
{
	
}
