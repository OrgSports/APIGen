// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_AIR_5250.h"

void CAG_AIR_5250::loadFunctionList(CListBox* listTranslateFunction)
{
	
}

void CAG_AIR_5250::loadLanguageList(CListBox* listTranslateLanguage)
{
	
}

CAG_AIR_5250::CAG_AIR_5250()
{
	
}

CAG_AIR_5250::~CAG_AIR_5250()
{
	
}

void CAG_AIR_5250::generateHeader(CStringArray* pcsaHeader,
								  CStringArray* pcsaBody)
{}

void CAG_AIR_5250::appendBody(int nFunctionNum,
							  bool bPromptForValues,
							  CStringArray* pcsaArguments,
							  CStringArray* pcsaHeader,
							  CStringArray* pcsaBody)
{}

void CAG_AIR_5250::finalize(CStringArray* pcsaBody)
{}

void CAG_AIR_5250::declareVariable(AG_VARIABLE agVariable,
								   CStringArray* pcsaHeader,
								   bool* bValue)
{
	
}

