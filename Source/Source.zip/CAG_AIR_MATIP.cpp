// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_AIR_MATIP.h"

void CAG_AIR_MATIP::loadFunctionList(CListBox* listTranslateFunction)
{
	
}

void CAG_AIR_MATIP::loadLanguageList(CListBox* listTranslateLanguage)
{
	
}

CAG_AIR_MATIP::CAG_AIR_MATIP()
{
	
}

CAG_AIR_MATIP::~CAG_AIR_MATIP()
{
	
}

void CAG_AIR_MATIP::generateHeader(CStringArray* pcsaHeader,
								   CStringArray* pcsaBody)
{
	
}

void CAG_AIR_MATIP::appendBody(int nFunctionNum,
							   bool bPromptForValues,
							   CStringArray* pcsaArguments,
							   CStringArray* pcsaHeader,
							   CStringArray* pcsaBody)
{
	
}

void CAG_AIR_MATIP::finalize(CStringArray* pcsaBody)
{
	
}

void CAG_AIR_MATIP::declareVariable(AG_VARIABLE agVariable,
									CStringArray* pcsaHeader,
									bool* bValue)
{
	
}
