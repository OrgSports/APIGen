// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_AIR_EDS_J_J.h"

CAG_AIR_EDS_J_J::~CAG_AIR_EDS_J_J()
{
	
}

void CAG_AIR_EDS_J_J::checkDebug(bool b_Debug,
								 CString csFunctionName,
								 CStringArray* pcsaBody)
{
	
}

CAG_AIR_EDS_J_J::CAG_AIR_EDS_J_J()
{
	resetVariableFlags();	
}

void CAG_AIR_EDS_J_J::generateHeader(CStringArray* pcsaHeader,
									 CStringArray* pcsaBody)
{
	
}

void CAG_AIR_EDS_J_J::appendBody(int nFunctionNum,
								 bool bPromptForValues,
								 CStringArray* pcsaArguments,
								 CStringArray* pcsaHeader,
								 CStringArray* pcsaBody)
{
	
}

void CAG_AIR_EDS_J_J::finalize(CStringArray* pcsaBody)
{
	
}

void CAG_AIR_EDS_J_J::declareVariable(AG_VARIABLE agVariable,
									  CStringArray* pcsaHeader,
									  bool* bValue)
{
	
}
