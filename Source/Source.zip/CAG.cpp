// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG.h"

/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////

CAG::~CAG()
{
	
}

void CAG::loadFunctionList(CListBox* listTranslateFunction)
{
	
}

void CAG::loadLanguageList(CListBox* listTranslateLanguage)
{
	
}

void loadTerminalTypeList(CListBox* listTerminalTypes)
{
	
}

void CAG::generateHeader(CStringArray* pcsaHeader,
						 CStringArray* pcsaBody)
{
	
}

void CAG::appendBody(int nFunctionNum,
					 bool bPromptForValues,
					 CStringArray* pcsaArguments,
					 CStringArray* pcsaHeader,
					 CStringArray* pcsaBody)
{
	
}

void CAG::finalize(CStringArray* pcsaBody)
{
	
}

void CAG::checkDebug()
{
	
}

/////////////////////////////////////////////////////////////////////////////

CAG::CAG()
{
	
}

void CAG::declareVariable(AG_VARIABLE agVariable,
						  CStringArray* pcsaHeader,
						  bool* bValue)
{
	
}

/////////////////////////////////////////////////////////////////////////////

void CAG::loadTerminalTypeList(CListBox* listTerminalTypes)
{
}


void CAG::resetVariableFlags()
{

}