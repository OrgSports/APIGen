// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_AIR_5250_Ax.h"

void CAG_AIR_5250_Ax::checkDebug()
{
	
}

CAG_AIR_5250_Ax::CAG_AIR_5250_Ax()
{
	APIFlavor=AIRAx_API;	
}

CAG_AIR_5250_Ax::~CAG_AIR_5250_Ax()
{
	
}

void CAG_AIR_5250_Ax::generateHeader(CStringArray* pcsaHeader,
									 CStringArray* pcsaBody)
{
	
}

void CAG_AIR_5250_Ax::appendBody(int nFunctionNum,
								 bool bPromptForValues,
								 CStringArray* pcsaArguments,
								 CStringArray* pcsaHeader,
								 CStringArray* pcsaBody)
{
	
}

void CAG_AIR_5250_Ax::finalize(CStringArray* pcsaBody)
{
	
}

void CAG_AIR_5250_Ax::declareVariable(AG_VARIABLE agVariable,
									  CStringArray* pcsaHeader,
									  bool* bValue)
{
	
}
