// Static Model


#ifndef __CAG_MCS_AX_3270_JS__
#define __CAG_MCS_AX_3270_JS__


// Include files
#include "CAG_MCS_Ax_3270.h"
class CAG_MCS_Ax_3270_JS : public CAG_MCS_Ax_3270
{

public:

	~CAG_MCS_Ax_3270_JS();

protected:

	CAG_MCS_Ax_3270_JS();

};// END CLASS DEFINITION CAG_MCS_Ax_3270_JS

#endif // __CAG_MCS_AX_3270_JS__
