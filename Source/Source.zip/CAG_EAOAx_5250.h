// Static Model


#ifndef __CAG_EAOAX_5250__
#define __CAG_EAOAX_5250__


// Include files
#include "CAG_EAOAx.h"
class CAG_EAOAx_5250 : public CAG_EAOAx
{

public:

	~CAG_EAOAx_5250();

	void loadFunctionList(CListBox* listTranslateFunction);

protected:

	CAG_EAOAx_5250();

};// END CLASS DEFINITION CAG_EAOAx_5250

#endif // __CAG_EAOAX_5250__
