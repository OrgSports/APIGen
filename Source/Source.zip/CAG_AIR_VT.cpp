// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_AIR_VT.h"

void CAG_AIR_VT::loadFunctionList(CListBox* listTranslateFunction)
{
	
}

void CAG_AIR_VT::loadLanguageList(CListBox* listTranslateLanguage)
{
	
}

CAG_AIR_VT::CAG_AIR_VT()
{
	
}

CAG_AIR_VT::~CAG_AIR_VT()
{
	
}

void CAG_AIR_VT::generateHeader(CStringArray* pcsaHeader,
								CStringArray* pcsaBody)
{}

void CAG_AIR_VT::appendBody(int nFunctionNum,
							bool bPromptForValues,
							CStringArray* pcsaArguments,
							CStringArray* pcsaHeader,
							CStringArray* pcsaBody)
{}

void CAG_AIR_VT::finalize(CStringArray* pcsaBody)
{}

void CAG_AIR_VT::declareVariable(AG_VARIABLE agVariable,
								 CStringArray* pcsaHeader,
								 bool* bValue)
{
	
}
