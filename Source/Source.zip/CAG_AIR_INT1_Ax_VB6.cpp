// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_AIR_INT1_Ax_VB6.h"

CAG_AIR_INT1_Ax_VB6::CAG_AIR_INT1_Ax_VB6()
{
	resetVariableFlags();	
}

CAG_AIR_INT1_Ax_VB6::~CAG_AIR_INT1_Ax_VB6()
{
	
}

void CAG_AIR_INT1_Ax_VB6::checkDebug(bool b_Debug,
									 CString csFunctionName,
									 CStringArray* pcsaBody)
{
	
}

void CAG_AIR_INT1_Ax_VB6::generateHeader(CStringArray* pcsaHeader,
										 CStringArray* pcsaBody)
{
	
}

void CAG_AIR_INT1_Ax_VB6::appendBody(int nFunctionNum,
									 bool bPromptForValues,
									 CStringArray* pcsaArguments,
									 CStringArray* pcsaHeader,
									 CStringArray* pcsaBody)
{
	
}

void CAG_AIR_INT1_Ax_VB6::finalize(CStringArray* pcsaBody)
{
	
}

void CAG_AIR_INT1_Ax_VB6::declareVariable(AG_VARIABLE agVariable,
										  CStringArray* pcsaHeader,
										  bool* bValue)
{
	
}

void CAG_AIR_INT1_Ax_VB6::resetVariableFlags()
{
}