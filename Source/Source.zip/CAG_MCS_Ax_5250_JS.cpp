// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_MCS_Ax_5250_JS.h"

CAG_MCS_Ax_5250_JS::~CAG_MCS_Ax_5250_JS()
{
	
}

CAG_MCS_Ax_5250_JS::CAG_MCS_Ax_5250_JS()
{
	
}
