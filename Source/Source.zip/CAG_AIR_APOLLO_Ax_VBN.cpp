// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_AIR_APOLLO_Ax_VBN.h"

CAG_AIR_APOLLO_Ax_VBN::~CAG_AIR_APOLLO_Ax_VBN()
{
	
}

void CAG_AIR_APOLLO_Ax_VBN::checkDebug(bool b_Debug,
									   CString csFunctionName,
									   CStringArray* pcsaBody)
{
	
}

CAG_AIR_APOLLO_Ax_VBN::CAG_AIR_APOLLO_Ax_VBN()
{
	resetVariableFlags();	
}

void CAG_AIR_APOLLO_Ax_VBN::generateHeader(CStringArray* pcsaHeader,
										   CStringArray* pcsaBody)
{
	
}

void CAG_AIR_APOLLO_Ax_VBN::appendBody(int nFunctionNum,
									   bool bPromptForValues,
									   CStringArray* pcsaArguments,
									   CStringArray* pcsaHeader,
									   CStringArray* pcsaBody)
{
	
}

void CAG_AIR_APOLLO_Ax_VBN::finalize(CStringArray* pcsaBody)
{
	
}

void CAG_AIR_APOLLO_Ax_VBN::declareVariable(AG_VARIABLE agVariable,
											CStringArray* pcsaHeader,
											bool* bValue)
{
	
}

void CAG_AIR_APOLLO_Ax_VBN::resetVariableFlags()
{
}