// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_ICONN_VBN.h"

CAG_ICONN_VBN::CAG_ICONN_VBN()
{
	
}

CAG_ICONN_VBN::~CAG_ICONN_VBN()
{
	
}

void CAG_ICONN_VBN::declareVariable(AG_VARIABLE agVariable,
										 CStringArray* pcsaHeader,
										 bool* bValue)
{
	
}

void CAG_ICONN_VBN::checkDebug(bool b_Debug,
									CString csFunctionName,
									CStringArray* pcsaBody)
{
	
}

void CAG_ICONN_VBN::generateHeader(CStringArray* csaHeader,
										CStringArray* csaBody)
{
	
}

void CAG_ICONN_VBN::appendBody(int nFunctionNum,
									bool bPromptForValues,
									CStringArray* csaArguments,
									CStringArray* csaHeader,
									CStringArray* csaBody)
{
	
}

void CAG_ICONN_VBN::finalize(CStringArray* pcsaBody)
{
	
}
