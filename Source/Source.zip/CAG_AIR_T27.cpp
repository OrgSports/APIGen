// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_AIR_T27.h"

void CAG_AIR_T27::loadFunctionList(CListBox* listTranslateFunction)
{
	
}

void CAG_AIR_T27::loadLanguageList(CListBox* listTranslateLanguage)
{
	
}

CAG_AIR_T27::CAG_AIR_T27()
{
	
}

CAG_AIR_T27::~CAG_AIR_T27()
{
	
}

void CAG_AIR_T27::generateHeader(CStringArray* pcsaHeader,
								 CStringArray* pcsaBody)
{
	
}

void CAG_AIR_T27::appendBody(int nFunctionNum,
							 bool bPromptForValues,
							 CStringArray* pcsaArguments,
							 CStringArray* pcsaHeader,
							 CStringArray* pcsaBody)
{
	
}

void CAG_AIR_T27::finalize(CStringArray* pcsaBody)
{
	
}

void CAG_AIR_T27::declareVariable(AG_VARIABLE agVariable,
								  CStringArray* pcsaHeader,
								  bool* bValue)
{
	
}
