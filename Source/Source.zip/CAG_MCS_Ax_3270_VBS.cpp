// Static Model
#include "stdafx.h"
#include "apigen.h"

#include "CAG_MCS_Ax_3270_VBS.h"

CAG_MCS_Ax_3270_VBS::~CAG_MCS_Ax_3270_VBS()
{
	
}

CAG_MCS_Ax_3270_VBS::CAG_MCS_Ax_3270_VBS()
{
	
}
